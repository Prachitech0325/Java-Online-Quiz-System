package model;
import java.util.List;
public class Question {
    private int questionId; private int quizId; private String questionText; private int mark; private List<Option> options;
    public int getQuestionId(){return questionId;} public void setQuestionId(int id){this.questionId=id;}
    public int getQuizId(){return quizId;} public void setQuizId(int q){this.quizId=q;}
    public String getQuestionText(){return questionText;} public void setQuestionText(String t){this.questionText=t;}
    public int getMark(){return mark;} public void setMark(int m){this.mark=m;}
    public List<Option> getOptions(){return options;} public void setOptions(List<Option> o){this.options=o;}
}
