
package service;
import java.sql.*;
import dao.QuizDAO;
import model.Quiz;
import util.DBUtil;

public class QuizService {
    public void createQuiz(Quiz quiz) throws Exception {
        Connection con = null;
        try {
            con = DBUtil.getConnection();
            con.setAutoCommit(false);
            new QuizDAO().insertQuiz(con, quiz);
            con.commit();
        } catch(Exception e) {
            if(con!=null) con.rollback();
            throw e;
        } finally {
            if(con!=null) con.close();
        }
    }
}
