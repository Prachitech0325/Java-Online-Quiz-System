
package dao;
import java.sql.*;
import model.Quiz;

public class QuizDAO {
    public void insertQuiz(Connection con, Quiz quiz) throws SQLException {
        PreparedStatement ps =
            con.prepareStatement("INSERT INTO quiz(title) VALUES(?)");
        ps.setString(1, quiz.getTitle());
        ps.executeUpdate();
    }
}
