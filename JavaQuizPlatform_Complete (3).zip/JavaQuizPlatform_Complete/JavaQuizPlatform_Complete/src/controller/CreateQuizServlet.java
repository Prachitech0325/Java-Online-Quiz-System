
package controller;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import model.Quiz;
import service.QuizService;

public class CreateQuizServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {
        try {
            Quiz q = new Quiz();
            q.setTitle(req.getParameter("title"));
            new QuizService().createQuiz(q);
            res.sendRedirect("success.jsp");
        } catch(Exception e) {
            res.sendError(500);
        }
    }
}
