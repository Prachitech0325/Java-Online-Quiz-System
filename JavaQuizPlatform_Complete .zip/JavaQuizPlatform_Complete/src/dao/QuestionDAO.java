package dao;
import model.Option; import model.Question; import model.Quiz;
import java.sql.*; import java.util.ArrayList; import java.util.List;
public class QuestionDAO {
    public void addQuestionWithOptions(Question q) throws SQLException {
        String qSql="INSERT INTO questions(quiz_id, question_text, mark) VALUES(?,?,?)";
        try (Connection con=DBUtil.getConnection(); PreparedStatement psQ=con.prepareStatement(qSql, Statement.RETURN_GENERATED_KEYS)) {
            con.setAutoCommit(false);
            psQ.setInt(1, q.getQuizId()); psQ.setString(2, q.getQuestionText()); psQ.setInt(3, q.getMark()); psQ.executeUpdate();
            int qId; try (ResultSet rs=psQ.getGeneratedKeys()){ if(!rs.next()){ con.rollback(); throw new SQLException("Failed to get question id"); } qId=rs.getInt(1); }
            String oSql="INSERT INTO options(question_id, option_text, is_correct) VALUES(?,?,?)";
            try (PreparedStatement psO=con.prepareStatement(oSql)){ for(Option op : q.getOptions()){ psO.setInt(1,qId); psO.setString(2,op.getOptionText()); psO.setBoolean(3,op.isCorrect()); psO.addBatch(); } psO.executeBatch(); }
            con.commit(); con.setAutoCommit(true);
        }
    }
    public Quiz getQuizWithQuestionsAndOptions(int quizId) throws SQLException {
        QuizDAO quizDAO=new QuizDAO(); Quiz quiz=quizDAO.getQuizById(quizId); if(quiz==null) return null;
        List<Question> questions=new ArrayList<>(); String qSql="SELECT * FROM questions WHERE quiz_id = ?"; String oSql="SELECT * FROM options WHERE question_id = ?";
        try (Connection con=DBUtil.getConnection(); PreparedStatement psQ=con.prepareStatement(qSql)) {
            psQ.setInt(1, quizId); try (ResultSet rsQ=psQ.executeQuery()){ while(rsQ.next()){ Question q=new Question(); q.setQuestionId(rsQ.getInt("question_id")); q.setQuizId(rsQ.getInt("quiz_id")); q.setQuestionText(rsQ.getString("question_text")); q.setMark(rsQ.getInt("mark"));
                    List<Option> options=new ArrayList<>(); try (PreparedStatement psO=con.prepareStatement(oSql)){ psO.setInt(1,q.getQuestionId()); try (ResultSet rsO=psO.executeQuery()){ while(rsO.next()){ Option op=new Option(); op.setOptionId(rsO.getInt("option_id")); op.setQuestionId(rsO.getInt("question_id")); op.setOptionText(rsO.getString("option_text")); op.setCorrect(rsO.getBoolean("is_correct")); options.add(op); } } }
                    q.setOptions(options); questions.add(q); } }
        }
        quiz.setQuestions(questions); return quiz;
    }
}
