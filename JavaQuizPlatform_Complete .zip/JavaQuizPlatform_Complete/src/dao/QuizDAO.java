package dao;
import model.Quiz;
import java.sql.*; import java.util.ArrayList; import java.util.List;
public class QuizDAO {
    public int createQuiz(Quiz quiz) throws SQLException {
        String sql="INSERT INTO quizzes(title, description, duration_min, created_by, is_active) VALUES(?,?,?,?,?)";
        try (Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)){
            ps.setString(1,quiz.getTitle()); ps.setString(2,quiz.getDescription()); ps.setInt(3,quiz.getDurationMin()); ps.setInt(4,quiz.getCreatedBy()); ps.setBoolean(5,true);
            int rows=ps.executeUpdate(); if(rows==0) return -1; try (ResultSet rs=ps.getGeneratedKeys()){ if(rs.next()){ int id=rs.getInt(1); quiz.setQuizId(id); return id; } }
        } return -1;
    }
    public List<Quiz> getAllActiveQuizzes() throws SQLException {
        List<Quiz> list=new ArrayList<>(); String sql="SELECT * FROM quizzes WHERE is_active = 1";
        try (Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement(sql); ResultSet rs=ps.executeQuery()){
            while(rs.next()){ Quiz q=new Quiz(); q.setQuizId(rs.getInt("quiz_id")); q.setTitle(rs.getString("title")); q.setDescription(rs.getString("description")); q.setDurationMin(rs.getInt("duration_min")); q.setCreatedBy(rs.getInt("created_by")); q.setActive(rs.getBoolean("is_active")); list.add(q);} }
        return list;
    }
    public Quiz getQuizById(int quizId) throws SQLException {
        String sql="SELECT * FROM quizzes WHERE quiz_id = ?"; try (Connection con=DBUtil.getConnection(); PreparedStatement ps=con.prepareStatement(sql)){ ps.setInt(1,quizId); try (ResultSet rs=ps.executeQuery()){ if(rs.next()){ Quiz q=new Quiz(); q.setQuizId(rs.getInt("quiz_id")); q.setTitle(rs.getString("title")); q.setDescription(rs.getString("description")); q.setDurationMin(rs.getInt("duration_min")); q.setCreatedBy(rs.getInt("created_by")); q.setActive(rs.getBoolean("is_active")); return q; } } } return null;
    }
}
