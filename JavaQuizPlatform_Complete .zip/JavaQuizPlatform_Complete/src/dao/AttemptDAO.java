package dao;
import java.sql.*; import java.time.LocalDateTime; import java.util.Map;
public class AttemptDAO {
    public int saveAttempt(int quizId, int userId, int score, Map<Integer, Boolean> correctnessByQuestion, Map<Integer, Integer> chosenOptionByQuestion) throws SQLException {
        String aSql="INSERT INTO quiz_attempts(quiz_id, user_id, start_time, end_time, score) VALUES(?,?,?,?,?)";
        try (Connection con=DBUtil.getConnection(); PreparedStatement psA=con.prepareStatement(aSql, Statement.RETURN_GENERATED_KEYS)) {
            con.setAutoCommit(false);
            Timestamp now=Timestamp.valueOf(LocalDateTime.now()); psA.setInt(1,quizId); psA.setInt(2,userId); psA.setTimestamp(3,now); psA.setTimestamp(4,now); psA.setInt(5,score); psA.executeUpdate();
            int attemptId; try (ResultSet rs=psA.getGeneratedKeys()){ if(!rs.next()){ con.rollback(); throw new SQLException("Failed to get attempt id"); } attemptId=rs.getInt(1); }
            String aaSql="INSERT INTO attempt_answers(attempt_id, question_id, chosen_option_id, is_correct) VALUES(?,?,?,?)";
            try (PreparedStatement psAA=con.prepareStatement(aaSql)){ for(Map.Entry<Integer,Integer> e : chosenOptionByQuestion.entrySet()){ int qId=e.getKey(); int chosenOptId=e.getValue(); boolean correct=correctnessByQuestion.getOrDefault(qId,false); psAA.setInt(1,attemptId); psAA.setInt(2,qId); psAA.setInt(3,chosenOptId); psAA.setBoolean(4,correct); psAA.addBatch(); } psAA.executeBatch(); }
            con.commit(); con.setAutoCommit(true); return attemptId;
        }
    }
}
