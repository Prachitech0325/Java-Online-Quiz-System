package servlet; import model.Quiz; import service.QuizService; import javax.servlet.ServletException; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException; import java.sql.SQLException; import java.util.List;
@WebServlet("/participantDashboard") public class ParticipantDashboardServlet extends HttpServlet {
    private QuizService quizService=new QuizService();
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try{ List<Quiz> quizzes=quizService.getAllActiveQuizzes(); req.setAttribute("quizzes",quizzes); req.getRequestDispatcher("jsp/participantDashboard.jsp").forward(req,resp); } catch(SQLException e){ throw new ServletException(e); }
    }
}
