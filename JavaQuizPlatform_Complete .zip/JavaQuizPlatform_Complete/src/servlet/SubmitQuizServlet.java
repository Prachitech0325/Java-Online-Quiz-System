package servlet; import model.Option; import model.Question; import model.Quiz; import model.User; import service.AttemptService; import service.QuizService; import javax.servlet.ServletException; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException; import java.sql.SQLException; import java.util.HashMap; import java.util.Map;
@WebServlet("/submitQuiz") public class SubmitQuizServlet extends HttpServlet {
    private QuizService quizService=new QuizService(); private AttemptService attemptService=new AttemptService();
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session=req.getSession(); User user=(User)session.getAttribute("currentUser"); if(user==null){ resp.sendRedirect("jsp/login.jsp"); return; }
        int quizId=Integer.parseInt(req.getParameter("quizId")); try{ Quiz quiz=quizService.getQuizWithQuestions(quizId); int score=0; Map<Integer,Boolean> correctnessMap=new HashMap<>(); Map<Integer,Integer> chosenMap=new HashMap<>();
            for(Question q : quiz.getQuestions()){ String param="q_"+q.getQuestionId(); String chosenOptStr=req.getParameter(param); if(chosenOptStr!=null){ int chosenOptId=Integer.parseInt(chosenOptStr); boolean correct=false; for(Option op : q.getOptions()){ if(op.getOptionId()==chosenOptId && op.isCorrect()){ correct=true; score+=q.getMark(); break; } } correctnessMap.put(q.getQuestionId(),correct); chosenMap.put(q.getQuestionId(),chosenOptId); } }
            int attemptId=attemptService.saveAttempt(quizId,user.getUserId(),score,correctnessMap,chosenMap);
            req.setAttribute("quiz",quiz); req.setAttribute("score",score); req.setAttribute("attemptId",attemptId); req.getRequestDispatcher("jsp/result.jsp").forward(req,resp);
        } catch(SQLException e){ throw new ServletException(e); }
    }
}
