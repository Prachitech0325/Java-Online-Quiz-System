package servlet; import model.Quiz; import service.QuizService; import javax.servlet.ServletException; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException; import java.sql.SQLException;
@WebServlet("/takeQuiz") public class TakeQuizServlet extends HttpServlet {
    private QuizService quizService=new QuizService();
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int quizId=Integer.parseInt(req.getParameter("quizId")); try{ Quiz quiz=quizService.getQuizWithQuestions(quizId); req.setAttribute("quiz",quiz); req.getRequestDispatcher("jsp/takeQuiz.jsp").forward(req,resp);} catch(SQLException e){ throw new ServletException(e); }
    }
}
