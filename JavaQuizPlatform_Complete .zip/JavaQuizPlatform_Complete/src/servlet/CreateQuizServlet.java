package servlet; import model.Quiz; import model.User; import service.QuizService; import javax.servlet.ServletException; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException; import java.sql.SQLException;
@WebServlet("/createQuiz") public class CreateQuizServlet extends HttpServlet { private QuizService quizService=new QuizService();
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session=req.getSession(); User current=(User)session.getAttribute("currentUser"); if(current==null){ resp.sendRedirect("jsp/login.jsp"); return; }
        String title=req.getParameter("title"); String desc=req.getParameter("description"); int duration=Integer.parseInt(req.getParameter("duration"));
        Quiz quiz=new Quiz(); quiz.setTitle(title); quiz.setDescription(desc); quiz.setDurationMin(duration); quiz.setCreatedBy(current.getUserId()); quiz.setActive(true);
        try{ int id=quizService.createQuiz(quiz); resp.sendRedirect("jsp/addQuestion.jsp?quizId="+id);} catch(SQLException e){ throw new ServletException(e); }
    }
}
