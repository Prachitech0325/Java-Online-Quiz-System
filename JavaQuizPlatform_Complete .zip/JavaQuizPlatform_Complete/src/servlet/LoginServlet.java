package servlet;
import model.Role; import model.User; import service.UserService;
import javax.servlet.ServletException; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException; import java.sql.SQLException;
@WebServlet("/login") public class LoginServlet extends HttpServlet {
    private UserService userService = new UserService();
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email=req.getParameter("email"); String password=req.getParameter("password");
        try{ User user=userService.authenticate(email,password); if(user==null){ req.setAttribute("error","Invalid email or password"); req.getRequestDispatcher("jsp/login.jsp").forward(req,resp); return; }
            HttpSession session=req.getSession(); session.setAttribute("currentUser",user);
            if(user.getRole()==Role.CREATOR || user.getRole()==Role.ADMIN) resp.sendRedirect("creatorDashboard"); else resp.sendRedirect("participantDashboard");
        } catch(SQLException e){ throw new ServletException(e); }
    }
}
