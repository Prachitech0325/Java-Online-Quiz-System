package servlet; import model.Option; import model.Question; import service.QuizService; import javax.servlet.ServletException; import javax.servlet.annotation.WebServlet; import javax.servlet.http.*; import java.io.IOException; import java.sql.SQLException; import java.util.ArrayList; import java.util.List;
@WebServlet("/addQuestion") public class AddQuestionServlet extends HttpServlet { private QuizService quizService=new QuizService();
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int quizId=Integer.parseInt(req.getParameter("quizId")); String questionText=req.getParameter("questionText"); int mark=Integer.parseInt(req.getParameter("mark"));
        String opt1=req.getParameter("opt1"); String opt2=req.getParameter("opt2"); String opt3=req.getParameter("opt3"); String opt4=req.getParameter("opt4"); int correctIndex=Integer.parseInt(req.getParameter("correct"));
        Question q=new Question(); q.setQuizId(quizId); q.setQuestionText(questionText); q.setMark(mark);
        List<Option> options=new ArrayList<>(); String[] optTexts={opt1,opt2,opt3,opt4};
        for(int i=0;i<4;i++){ Option op=new Option(); op.setOptionText(optTexts[i]); op.setCorrect((i+1)==correctIndex); options.add(op); }
        q.setOptions(options);
        try{ quizService.addQuestion(q); resp.sendRedirect("jsp/addQuestion.jsp?quizId="+quizId+"&msg=Question+added"); } catch(SQLException e){ throw new ServletException(e); }
    }
}
