package service;
import dao.UserDAO; import model.User;
import java.sql.SQLException;
public class UserService { private UserDAO userDAO=new UserDAO(); public void register(User user) throws SQLException{ userDAO.register(user);} public User authenticate(String email,String password) throws SQLException{return userDAO.findByEmailAndPassword(email,password);} }
