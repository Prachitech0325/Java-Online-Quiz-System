package model;
public class Option {
    private int optionId; private int questionId; private String optionText; private boolean correct;
    public int getOptionId(){return optionId;} public void setOptionId(int id){this.optionId=id;}
    public int getQuestionId(){return questionId;} public void setQuestionId(int q){this.questionId=q;}
    public String getOptionText(){return optionText;} public void setOptionText(String t){this.optionText=t;}
    public boolean isCorrect(){return correct;} public void setCorrect(boolean c){this.correct=c;}
}
