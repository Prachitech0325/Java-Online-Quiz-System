package model;
public enum Role { ADMIN, CREATOR, PARTICIPANT }
